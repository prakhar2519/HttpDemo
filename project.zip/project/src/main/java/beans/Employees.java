
package beans;


public class Employees extends Jobs{
    int EmpID;
    String EmpName;
    char EmpGender;
    String EmpCity;
    long EmpContactNumber;
    String EmpEmailID;
    String EmpPassword;
    String EmpImage;
    int ManagerID;

    public int getEmpID() {
	return EmpID;
    }

    public void setEmpID(int EmpID) {
	this.EmpID = EmpID;
    }

    public String getEmpName() {
	return EmpName;
    }

    public void setEmpName(String EmpName) {
	this.EmpName = EmpName;
    }

    public char getEmpGender() {
	return EmpGender;
    }

    public void setEmpGender(char EmpGender) {
	this.EmpGender = EmpGender;
    }

    public String getEmpCity() {
	return EmpCity;
    }

    public void setEmpCity(String EmpCity) {
	this.EmpCity = EmpCity;
    }

    public long getEmpContactNumber() {
	return EmpContactNumber;
    }

    public void setEmpContactNumber(long EmpContactNumber) {
	this.EmpContactNumber = EmpContactNumber;
    }

    public String getEmpEmailID() {
	return EmpEmailID;
    }

    public void setEmpEmailID(String EmpEmailID) {
	this.EmpEmailID = EmpEmailID;
    }

    public String getEmpPassword() {
	return EmpPassword;
    }

    public void setEmpPassword(String EmpPassword) {
	this.EmpPassword = EmpPassword;
    }

    public String getEmpImage() {
	return EmpImage;
    }

    public void setEmpImage(String EmpImage) {
	this.EmpImage = EmpImage;
    }

    public int getManagerID() {
	return ManagerID;
    }

    public void setManagerID(int ManagerID) {
	this.ManagerID = ManagerID;
    }

    public int getJobID() {
	return JobID;
    }

    public void setJobID(int JobID) {
	this.JobID = JobID;
    }

    public int getDepartmentID() {
	return DepartmentID;
    }

    public void setDepartmentID(int DepartmentID) {
	this.DepartmentID = DepartmentID;
    }
    
    
}
