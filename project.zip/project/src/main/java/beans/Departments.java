
package beans;


public class Departments {
    protected int DepartmentID;
    private String DepartmentName;

    public int getDepartmentID() {
	return DepartmentID;
    }

    public void setDepartmentID(int DepartmentID) {
	this.DepartmentID = DepartmentID;
    }

    public String getDepartmentName() {
	return DepartmentName;
    }

    public void setDepartmentName(String DepartmentName) {
	this.DepartmentName = DepartmentName;
    }

    
    
}
