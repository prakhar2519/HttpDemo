
package datalayer;
import java.sql.*;
import java.util.*;

import beans.Jobs;

public class DALJobs extends DBOperations{
    public DALJobs(){
	
    }
    public int getLevels (int JobID){
	int level=0;
	try {
	    PreparedStatement ps = con.prepareStatement("SELECT Level FROM Jobs WHERE JobID=?");
	    ps.setString(1, String.valueOf(JobID));
	    ResultSet rs = ps.executeQuery();
	    
	    while(rs.next()){
		level = rs.getInt("Level");
	    }
	} catch (Exception e) {
	    System.out.println(e);
	}
	return level;
    }
    public ArrayList<Jobs> getJobs(int index,int Level){
	ArrayList<Jobs> AJ = new ArrayList<Jobs>();
	try {
	    PreparedStatement ps = con.prepareStatement("SELECT * FROM Jobs WHERE DepartmentID=? AND Level=?");
	    ps.setString(1, String.valueOf(index));
	    ps.setString(2, String.valueOf(Level+1));
	    ResultSet rs = ps.executeQuery();
	    while(rs.next()){
		Jobs j = new Jobs();
		j.setJobID(rs.getInt("JobID"));
		j.setJobName(rs.getString("JobName"));
		AJ.add(j);
	    }
	    
	} catch (Exception e) {
	    System.out.println(e);
	}
	return AJ;
    }
    
    public String getJobByJobID(int ID){
	String job="";
	try {
	    PreparedStatement ps = con.prepareStatement("SELECT * FROM Jobs WHERE JobID=?");
	    ps.setString(1, String.valueOf(ID));
	    ResultSet rs = ps.executeQuery();
	    while(rs.next()){
		job=rs.getString("JobName");
	    }
	} catch (Exception e) {
	    System.out.println(e);
	}
	return job;
    }
    
    
}
