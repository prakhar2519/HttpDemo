
package datalayer;
import java.sql.*;

public class DBOperations {
protected static Connection con;
	
	public static Connection getConn() {
		
		try {
			
			 
			Class.forName("com.mysql.cj.jdbc.Driver"); 
			
			
			con = DriverManager.getConnection("jdbc:mysql://localhost:3306/Task","root","root");
			
		} catch (Exception e) {
			e.printStackTrace();
					}
		
		return con;
    }
}
