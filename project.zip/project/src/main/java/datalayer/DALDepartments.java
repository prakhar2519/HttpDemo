
package datalayer;
import java.sql.*;
import java.util.*;

import beans.Departments;


public class DALDepartments extends DBOperations{
    public DALDepartments(){

    }
    
    public ArrayList<Departments> getDepartments(){
	ArrayList<beans.Departments> AD = new ArrayList<>();
	
	try {
	    PreparedStatement ps = con.prepareStatement("SELECT * FROM Departments");
	    ResultSet rs = ps.executeQuery();
	    while(rs.next()){
		Departments d= new Departments();
		
		d.setDepartmentID(Integer.parseInt(rs.getString("DepartmentID")));
		d.setDepartmentName(rs.getString("DepartmentName"));
		
		AD.add(d);
	    }
	} catch (Exception e) {
	    System.out.println(e);
	}
	return AD;
	
    }
    
    public Departments getDepartmentByJobID(int x){
	Departments d = new Departments();
	try {
	    PreparedStatement ps = con.prepareStatement("SELECT Departments.DepartmentID, Departments.DepartmentName FROM Jobs INNER JOIN Departments ON Jobs.DepartmentID = Departments.DepartmentID WHERE (Jobs.JobID=?)");
	    ps.setString(1, String.valueOf(x));
	    ResultSet rs = ps.executeQuery();
	    while(rs.next()){
		d.setDepartmentID(Integer.parseInt(rs.getString("DepartmentID")));
		d.setDepartmentName(rs.getString("DepartmentName"));
	    }
	  
	} catch (Exception e) {
	    System.out.println(e);
	}
	return d;
    }
   
}
