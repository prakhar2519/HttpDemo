
package datalayer;
import beans.Employees;
import java.sql.*;
import java.util.*;

public class DALEmployees extends DBOperations{
    public DALEmployees(){
	
    }
    
    public Employees authenticateLogin(String uid, String pwd){
	Employees emp = new Employees();
	try {
	    PreparedStatement ps = con.prepareStatement("SELECT * FROM Employees WHERE EmpID=? AND EmpPassword=?");
	    
	    ps.setString(1, uid);
	    ps.setString(2, pwd);
	    ResultSet rs = ps.executeQuery();
	    while (rs.next()) {
		emp.setEmpID(Integer.parseInt(rs.getString("EmpID")));
		emp.setEmpName(rs.getString("EmpName"));
		emp.setEmpPassword(rs.getString("EmpPassword"));
		emp.setEmpCity(rs.getString("EmpCity"));
		emp.setEmpContactNumber(Long.parseLong(rs.getString("EmpContactNumber")));
		emp.setEmpEmailID(rs.getString("EmpEmailID"));
		emp.setJobID(Integer.parseInt(rs.getString("JobID")));
		emp.setEmpImage(rs.getString("EmpImage"));
		emp.setManagerID(Integer.parseInt(rs.getString("ManagerID")));
		emp.setEmpGender(rs.getString("EmpGender").charAt(0));
	    }
	    
	    
	} catch (Exception e) {
	    System.out.println(e);
	}
	
	return emp;
    }
    
    public void addEmployee(Employees empNew){
	try {
	    PreparedStatement ps = con.prepareStatement("INSERT INTO Employees (EmpName,EmpGender,EmpCity,EmpContactNumber,EmpEmailID,JobID,ManagerID) VALUES(?,?,?,?,?,?,?)");
	    
	    ps.setString(1, empNew.getEmpName());
	    ps.setString(2, "");
	    ps.setString(3, "");
	    ps.setString(4, Long.toString(empNew.getEmpContactNumber()));
	    ps.setString(5, "@");
	    ps.setString(6, Integer.toString(empNew.getJobID()));
	    ps.setString(7, Integer.toString(empNew.getManagerID()));
	    
	    ps.executeUpdate();
	    
	    
	} catch (Exception e) {
	    System.out.println(e);
	}
    }
    
    public ArrayList<Employees> showEmpAdded(int ID){
	ArrayList<Employees> AE = new ArrayList<Employees>();
	try {
	    PreparedStatement ps = con.prepareStatement("SELECT Employees.EmpID, Employees.EmpName, Employees.EmpContactNumber, Jobs.JobID, Jobs.JobName, Departments.DepartmentID, Departments.DepartmentName FROM Employees INNER JOIN Jobs ON Employees.JobID = Jobs.JobID INNER JOIN Departments ON Jobs.DepartmentID = Departments.DepartmentID WHERE(Employees.ManagerID = ?)");	  
	    ps.setString(1, String.valueOf(ID));
	    ResultSet rs = ps.executeQuery();
	    
	    while(rs.next()){
		Employees emp = new Employees();
		emp.setEmpID(Integer.parseInt(rs.getString("EmpID")));
		emp.setEmpName(rs.getString("EmpName"));
		emp.setEmpContactNumber(Long.parseLong(rs.getString("EmpContactNumber")));
		emp.setJobID(Integer.parseInt(rs.getString("JobID")));
		emp.setJobName(rs.getString("JobName"));
		emp.setDepartmentID(Integer.parseInt(rs.getString("DepartmentID")));
		emp.setDepartmentName(rs.getString("DepartmentName"));
				
		AE.add(emp);
	    }

	} catch (Exception e) {
	    System.out.println(e);
	}
	return AE;
    }
    
    public Employees getEmpByID(int x){
	Employees emp = new Employees();
	try {
	    PreparedStatement ps = con.prepareStatement("SELECT * from Employees WHERE EmpID=?");
	    ps.setString(1, String.valueOf(x));
	    ResultSet rs = ps.executeQuery();
	    
	    while(rs.next()){
		emp.setEmpID(Integer.parseInt(rs.getString("EmpID")));
		emp.setEmpName(rs.getString("EmpName"));
		emp.setEmpContactNumber(Long.parseLong(rs.getString("EmpContactNumber")));
		emp.setJobID(Integer.parseInt(rs.getString("JobID")));
		emp.setEmpCity(rs.getString("EmpCity"));
		emp.setEmpEmailID(rs.getString("EmpEmailID"));
		emp.setManagerID(rs.getInt("ManagerID"));
		emp.setEmpGender(rs.getString("EmpGender").charAt(0));
				
	    }
	} catch (Exception e) {
	    System.out.println(e);
	}
	return emp;
    }
    
    public void updateDetails(Employees emp){
	try {
	    PreparedStatement ps = con.prepareStatement("UPDATE Employees SET EmpGender=? , EmpCity=? , EmpEmailID=? WHERE EmpID=?");
	    ps.setString(1, String.valueOf(emp.getEmpGender()));
	    ps.setString(2, emp.getEmpCity());
	    ps.setString(3, emp.getEmpEmailID());
	    ps.setString(4, String.valueOf(emp.getEmpID()));
	    ps.executeUpdate();
	} catch (Exception e) {
	    System.out.println(e);
	}
    }
    public void updateAllDetails(Employees emp){
	try {
	    
	} catch (Exception e) {
	    System.out.println(e);
	}
    }
    public void updatePassword(Employees emp){
	try {
	    PreparedStatement ps = con.prepareStatement("UPDATE Employees SET EmpPassword=? WHERE EmpID=?");
	    ps.setString(1,emp.getEmpPassword());
	    ps.setString(2, String.valueOf(emp.getEmpID()));
	    ps.executeUpdate();
	} catch (Exception e) {
	    System.out.println(e);
	}
    }
    
}
