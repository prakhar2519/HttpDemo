

  public enum Method {
		 ALL, GET, HEAD;
			      }

