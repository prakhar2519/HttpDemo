

import java.util.HashMap;
import java.util.Map;

public class Request {
	  private String method;
	  private String resource;
	  private String contenttype;
	  private Map<String, String> headers = new HashMap<String, String>();
	
	  public String getMethod() {
		return method;
	}
	public void setMethod(String method) {
		this.method = method;
	}
	public String getResource() {
		return resource;
	}
	public void setResource(String resource) {
		this.resource = resource;
	}
	public String getContenttype() {
		return contenttype;
	}
	public void setContenttype(String contenttype) {
		this.contenttype = contenttype;
	}
	public String getHeader(String headerName)  {
	    return headers.get(headerName);
	  }
	public Request(String method, String resource, String contenttype, Map<String, String> headers) {
		super();
		this.method = method;
		this.resource = resource;
		this.contenttype = contenttype;
		this.headers = headers;
	}
	 

}
