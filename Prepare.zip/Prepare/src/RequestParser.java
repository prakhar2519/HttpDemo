import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.HashMap;



public class RequestParser {
	
	public Request parse(InputStream inputStream) {
		
        try {
            BufferedReader reader = new BufferedReader(new InputStreamReader(inputStream));    // Initialize reader object for reading input stream
            String firstLine = reader.readLine();    // Read first line i.e. HTTP request
            String method = getMethod(firstLine);    // Extract method from request
            String resource = getResource(firstLine);    // Extract resource from request           
            HashMap<String, String> headers = getHeaders(reader);    // Get header values

            String contenttype = headers.get("Content-Length");    // Get content type
            return this.request.getRequest(method, resource, headers, contenttype);    // Return the request object
        } catch (IOException e) {    // Catch an exception
            return this.request.getRequestForInternalError();    // Return the error request object
        } catch (ArrayIndexOutOfBoundsException e) {    // Catch an exception
            return this.requestBuilder.getBadRequest();    // Return the request object for Bad request
        }
    }
	 
	private HashMap getHeaders(BufferedReader bufferedReader) throws IOException {    // Function to get headers
	        HashMap<String, String> headers = new HashMap<>();    // Initialize a hashmap
	        String line;
	        while ((line = bufferedReader.readLine()) != null) {    // Read the headers
	            if (this.EmptyLine(line)) {    // Check if line is empty
	                break;    // Break the loop
	            } else {
	                try {
	                    String ElementsOfLine[] = line.split(" ", 2);    // Split the line using space
	                    headers.put(key, value);    // Store the key-value pair in hashmap
	                } catch (ArrayIndexOutOfBoundsException e) {    // Catch an exception
	                    throw e;    // Throw the exception
	                }
	            }
	        }
	        return headers;    // Return the hashmap
	}
	        
	        private String getUserContenttype(Request request) {    // Function to get content type 
	            return request.getHeader("contenttype");    // Return the content type
	        }
	        
	        private Boolean EmptyLine(String line) {    // Function to check if line is empty
	            return line.equals("");    // Return true or false
	        }
	        public RequestParser(RequestBuilder requestBuilder) {    // Constructor
	            this.requestBuilder = requestBuilder;    // Initialize request builder object
	        }
	        
	        
	       
