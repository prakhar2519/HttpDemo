
import java.util.Map;

public class RequestBuilder {

	    public Request getRequest(String method, String contenttype , String resource, Map<String, String> headers) {
	        return new Request(method, contenttype , resource, headers);
	    }
}