package src;

import java.io.*;
import java.net.Socket;
import java.nio.file.Files;
import java.util.HashMap;

public class RequestConnection implements Runnable {

    
    private Socket connectionSocket;     //  connecting to the server
    
    private HashMap<String, String> request;
   
    private HashMap<String, String> redirect;

    
    public RequestConnection(Socket connectionSocket) {

        this.connectionSocket = connectionSocket;

        this.request = new HashMap<>();
        this.redirect = new HashMap<>();
        redirect.put("/", "/index.html");       // Add key/value pairs to the redirect HashMap
        redirect.put("/index.htm", "/index.html");
        redirect.put("/index", "/index.html");
    }

   
    private void parseRequest() throws IOException {
        BufferedReader connectionReader = new BufferedReader(new InputStreamReader(connectionSocket.getInputStream())); // Connect a BufferedReader to the client socket's input stream and read it its request data
        String requestLine = connectionReader.readLine();    // Read in the top client request line.
        
        // if exist then
        if (requestLine != null) {      

           
            
            String[] requestLineParams = requestLine.split(" ");      // we get the values of the top line of the client request 

            // Extract the relevant information from the top line of the request
            String requestMethod = requestLineParams[0];
            String requestResource = requestLineParams[1];
            String requestProtocol = requestLineParams[2];

            // Add the Method, Resource and Protocol to the request HashMap
            request.put("Method", requestMethod);
            request.put("Resource", requestResource);
            request.put("Protocol", requestProtocol);

            // Read the next line of the client request header
            String headerLine = connectionReader.readLine();

            // While the request header still has lines to read we continue reading and
            // storing the values of each request field into the request HashMap
            while (!headerLine.isEmpty()) {
                String[] requestParams = headerLine.split(":", 2);     // Splits the request field into its key and value pair

                // Put the request field key and value into the request HashMap
                request.put(requestParams[0], requestParams[1].replaceFirst(" ", ""));

                // Read the next header line of the request
                headerLine = connectionReader.readLine();
            }
        }
    }

   
    private void sendResponse() throws IOException {

        // outStream to send information to the client connection
        DataOutputStream outStream = new DataOutputStream(connectionSocket.getOutputStream());

        // Get the file path of the file requested by the client connection and open the requested
        String resourcePath = request.get("Resource").toString();
        File file = new File("." + resourcePath);

        // If the file requested by the client is in the redirect HashMap then send the client a
        // HTTP 301 response and redirect the client to the new file address
        if (redirect.get(resourcePath) != null) {

            // Send the client a HTTP 301 request and redirect to new address
            outStream.writeBytes("HTTP/1.1 301 Moved Permanently\n" +
                    "Location: " + redirect.get(resourcePath));
        }

        // If the file requested does not exist send the client a HTTP 404 response with a webpage
        // that tells the client that the file was not found
        else if (!file.exists()) {

            // Create HTTP 404 response webpage
            String http404Response = "HTTP/1.1 404 Not Found\r\n\r\n" + "<!DOCTYPE html>\n" +
                    "<html>\n" +
                    "\n" +
                    "<head>\n" +
                    "    <title>HTTP SERVER</title>\n" +
                    "</head>\n" +
                    "\n" +
                    "<body><h1>\n" +
                    "404 Error: Page Not Found\n" +
                    "</h1></body>\n" +
                    "\n" +
                    "</html>";

            // Send the HTTP 404 response to the client using the UTF-8 encoding
            outStream.write(http404Response.getBytes("UTF-8"));
        }

        // If the file is not in the redirect HashMap and it exists then we send the client
        // a HTTP 200 response and serve the file
        else {

            //  input stream to read data from the file
            FileInputStream fileStream = new FileInputStream(file);
            String contentType = Files.probeContentType(file.toPath()); // Get the MIME file type of file that client is request
            BufferedInputStream bufInputStream = new BufferedInputStream(fileStream); // Create a BufferedInputStream to read data from the fileStream

            // Create an array of bytes the same length of the file requested 
            byte[] bytes = new byte[(int) file.length()];

            // Send the header of the HTTP 200 response
            outStream.writeBytes("HTTP/1.1 200 OK\r\nContent-Type: " + contentType + "\r\n\r\n");

            // Read in the data from file requested into the bytes array
            bufInputStream.read(bytes);

            // Send the data contained by the bytes array to the client connection and flush the output stream
            outStream.write(bytes);
            outStream.flush();
            bufInputStream.close();      // Close input stream
        }
        // Close output stream
        outStream.close();
    }

   
    @Override
    public void run() {
        try {
            // Parse the client request and store the request field keys/values inside of the request HashMap
            parseRequest();

            // Send an appropriate response to the client based on the request received by the server
            sendResponse();

            // Close client connection
            this.connectionSocket.close();
        } catch (IOException ex) {
            ex.printStackTrace();
        }
    }
}
