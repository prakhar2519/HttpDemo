package src;

import java.net.ServerSocket;
import java.net.Socket;


public class RequestServer {

    
    public static void main(String[] args) throws Exception {

        // Create ServerSocket on LocalHost
        ServerSocket serverSocket = new ServerSocket(2506);
        System.out.println(" connections on port 2505...\r\n");

        // for new client connections
        while(true) {

            // Accept new client connection
            Socket connectionSocket = serverSocket.accept();

            // Create new thread to handle client request
            Thread connectionThread = new Thread(new RequestConnection(connectionSocket));

            // Start the connection thread
            connectionThread.start();
            System.out.println("New connection on port 2506...\r\n");
        }
    }
}
